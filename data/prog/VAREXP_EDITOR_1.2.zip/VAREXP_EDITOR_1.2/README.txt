Licence d'utilisation de VAREXP_EDITOR

1. Définitions
   "Logiciel" fait référence au programme informatique VAREXP_EDITOR.
   "Utilisateur" désigne toute personne physique ou morale qui utilise le Logiciel.

2. Accord de licence
   En utilisant ce Logiciel, l'Utilisateur accepte les termes et conditions énoncés dans cette licence.

3. Droits de l'Utilisateur
   L'Utilisateur est autorisé à utiliser le Logiciel à des fins personnelles ou professionnelles, conformément aux lois en vigueur.

4. Restrictions
   a. L'Utilisateur n'est pas autorisé à redistribuer, vendre, louer ou sous-licencier le Logiciel sans l'autorisation écrite préalable du Titulaire des droits.

5. Droits de propriété intellectuelle
   Le Logiciel et tous les droits de propriété intellectuelle y afférents restent la propriété exclusive du Titulaire des droits.

6. Garantie
   Le Logiciel est fourni "tel quel", sans garantie d'aucune sorte.

7. Fin de licence
   Le Titulaire des droits se réserve le droit de résilier cette licence à tout moment en cas de violation des termes et conditions par l'Utilisateur.

8. Loi applicable
   Cette licence est régie par les lois francaises.

Gael GROSSO
05/10/2024
